function carregarFila() {
    return JSON.parse(localStorage.getItem("filaAtendimento") || "[]");
}

function salvarFila(fila) {
    localStorage.setItem("filaAtendimento", JSON.stringify(fila));
}

function entrarFila() {
    let nome = document.getElementById("nome").value;
    let curso = document.getElementById("curso").value;
    let assunto = document.getElementById("assunto").value;
    let pref = document.getElementById("preferencial").checked;

    if (!nome || !curso || !assunto) {
        alert("Preencha todos os campos");
        return;
    }

    let fila = carregarFila();

    fila.push({
        nome,
        curso,
        assunto,
        preferencial: pref,
        hora: Date.now()
    });

    salvarFila(fila);

    alert("Você entrou na fila! Aguarde seu chamado.");
}

function ordenarFila(fila) {
    return fila.sort((a, b) => {
        if (a.preferencial && !b.preferencial) return -1;
        if (!a.preferencial && b.preferencial) return 1;
        return a.hora - b.hora;
    });
}

function atualizarPainel() {
    let tabela = document.getElementById("tabela");
    if (!tabela) return;

    let fila = ordenarFila(carregarFila());
    tabela.innerHTML = "";

    fila.forEach(item => {
        let tr = document.createElement("tr");
        if (item.preferencial) tr.classList.add("preferencial");

        tr.innerHTML = `
            <td>${item.nome}</td>
            <td>${item.curso}</td>
            <td>${item.assunto}</td>
            <td>${new Date(item.hora).toLocaleTimeString()}</td>
            <td>${item.preferencial ? "Sim" : "Não"}</td>
        `;

        tabela.appendChild(tr);
    });

    setTimeout(atualizarPainel, 2000);
}

function chamarAluno() {
    let fila = ordenarFila(carregarFila());

    if (fila.length === 0) {
        alert("Nenhum aluno na fila");
        return;
    }

    let aluno = fila.shift();
    salvarFila(fila);
    document.getElementById("proximo").innerHTML = `Chamando: <strong>${aluno.nome}</strong>`;
}

atualizarPainel();
